import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class AvaliableVehicle extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Packages pkg=new Packages();
	private ConnectDB connect=new ConnectDB();
	private String query;
	private JTextField txtTrackId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AvaliableVehicle frame = new AvaliableVehicle();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ArrayList<Packages>data()
	{
		ArrayList<Packages>pData=new ArrayList<Packages>();
		try 
		{
			Connection connection;
			Statement st;
			ResultSet rs;
			connection=connect.DbConnect();
			st=connection.createStatement();
			query="select vehicle_id,vehicle_type,VT_model,engine_type,engine_displacement\r\n" + 
					"from vehicle;";
			rs=st.executeQuery(query);
			while(rs.next())
			{
				
				Packages produt=new Packages(rs.getInt("vehicle_id"), rs.getString("vehicle_type"), rs.getString("VT_model"), rs.getString("engine_type"), rs.getString("engine_displacement"));
				pData.add(produt);
			}
		
		}catch (SQLException e)
		{
			JOptionPane.showMessageDialog(null, "Error\n"+e);
		}
		return pData;
	}
	public void getData()
	{
		try{
		ArrayList<Packages> prod=null;
		prod=data();
		Object[] row=new Object[5];
		DefaultTableModel model=(DefaultTableModel) table.getModel();
		for(int i=0;i<prod.size();i++)
		{
			row[0]=prod.get(i).getVehicleID();
			row[1]=prod.get(i).getVehicleType();
			row[2]=prod.get(i).getVtModel();
			row[3]=prod.get(i).getEngine();
			row[4]=prod.get(i).getDisplacement();
			
			model.addRow(row);
		}
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public void searchProduct()
	{
		Connection conSearch=connect.DbConnect();
		Statement stSearch;
		ResultSet rstSearch;
		try{
			stSearch=conSearch.createStatement();
			query="select vehicle_id,vehicle_type,VT_model,engine_type,engine_displacement\r\n" + 
					"from vehicle WHERE vehicle_id='"+txtTrackId.getText()+"'";
			rstSearch=stSearch.executeQuery(query);
			if(rstSearch.next())
			{
				pkg.setVehicleID(rstSearch.getInt(1));
				pkg.setVehicleType(rstSearch.getString(2));
				pkg.setVtModel(rstSearch.getString(3));
				pkg.setEngine(rstSearch.getString(4));
				pkg.setDisplacement(rstSearch.getString(5));
				table.setModel(new DefaultTableModel(
						new Object[][] {
						},
						new String[] {
							"Track ID", "Package Name", "Location", "Status", "User"
						}
					));
				Object[] row=new Object[5];
				DefaultTableModel model=(DefaultTableModel) table.getModel();
				for(int i=0;i<7;i++)
				{
					row[0]=pkg.getVehicleID();
					row[1]=pkg.getVehicleType();
					row[2]=pkg.getVtModel();
					row[3]=pkg.getEngine();
					row[4]=pkg.getDisplacement();					
				}
					model.addRow(row);
			}else 
				{
					JOptionPane.showMessageDialog(null, "Error 404: DATA NOT FOUND");
				} 
			}catch (SQLException e){
				table.setModel(new DefaultTableModel(
						new Object[][] {
						},
						new String[] {
							"Track ID", "Package Name", "Location", "Status", "User"
						}
					));
				JOptionPane.showMessageDialog(null, "Error Occured While Executing Query\n"+e);
			}
	}
	public AvaliableVehicle() 
	{
		initialize();
		getData();
	}
	public void initialize()
	{
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		System.out.println(screenHeight);
		System.out.println(screenWidth);
		//frame.setSize(screenWidth / 2, screenHeight / 2);
		//setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, screenWidth,screenHeight);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(10, 0, 1290, 731);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(UIManager.getColor("TextField.foreground"));
		panel_2.setBounds(0, 31, 1400, 51);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton button = new JButton("EMPLOYEE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Employee().setVisible(true);
				setVisible(false);
			}
		});
		button.setToolTipText("Register");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Calibri", Font.BOLD, 15));
		button.setBorder(null);
		button.setBackground(Color.BLACK);
		button.setBounds(10, 11, 115, 23);
		panel_2.add(button);
		
		JButton button_1 = new JButton("Delivery");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Delivery().setVisible(true);
				setVisible(false);
			}
		});
		button_1.setToolTipText("Track");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Calibri", Font.BOLD, 15));
		button_1.setBorder(null);
		button_1.setBackground(Color.BLACK);
		button_1.setBounds(135, 11, 132, 23);
		panel_2.add(button_1);
		
		JButton btnVehicle = new JButton("Vehicle");
		btnVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Vehicle().setVisible(true);
				setVisible(false);
			}
		});
		btnVehicle.setToolTipText("Track");
		btnVehicle.setForeground(Color.WHITE);
		btnVehicle.setFont(new Font("Calibri", Font.BOLD, 15));
		btnVehicle.setBorder(null);
		btnVehicle.setBackground(Color.BLACK);
		btnVehicle.setBounds(277, 11, 138, 23);
		panel_2.add(btnVehicle);
		
		JButton button_3 = new JButton("Supplier");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Supplier().setVisible(true);
				setVisible(false);
			}
		});
		button_3.setToolTipText("Track");
		button_3.setForeground(Color.WHITE);
		button_3.setFont(new Font("Calibri", Font.BOLD, 15));
		button_3.setBorder(null);
		button_3.setBackground(Color.BLACK);
		button_3.setBounds(425, 11, 126, 23);
		panel_2.add(button_3);
		
		JButton button_4 = new JButton("Customer");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Customer().setVisible(true);
				setVisible(false);
			}
		});
		button_4.setToolTipText("Track");
		button_4.setForeground(Color.WHITE);
		button_4.setFont(new Font("Calibri", Font.BOLD, 15));
		button_4.setBorder(null);
		button_4.setBackground(Color.BLACK);
		button_4.setBounds(561, 11, 138, 23);
		panel_2.add(button_4);
		
		JButton button_5 = new JButton("Show Room");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Show_Room().setVisible(true);
				setVisible(false);
			}
		});
		button_5.setToolTipText("Track");
		button_5.setForeground(Color.WHITE);
		button_5.setFont(new Font("Calibri", Font.BOLD, 15));
		button_5.setBorder(null);
		button_5.setBackground(Color.BLACK);
		button_5.setBounds(709, 11, 132, 23);
		panel_2.add(button_5);
		
		JButton button_6 = new JButton("Order");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Order().setVisible(true);
				setVisible(false);
			}
		});
		button_6.setToolTipText("Track");
		button_6.setForeground(Color.WHITE);
		button_6.setFont(new Font("Calibri", Font.BOLD, 15));
		button_6.setBorder(null);
		button_6.setBackground(Color.BLACK);
		button_6.setBounds(851, 11, 132, 23);
		panel_2.add(button_6);
		
		JButton button_7 = new JButton("Payment");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Payment().setVisible(true);
				setVisible(false);
			}
		});
		button_7.setToolTipText("Track");
		button_7.setForeground(Color.WHITE);
		button_7.setFont(new Font("Calibri", Font.BOLD, 15));
		button_7.setBorder(null);
		button_7.setBackground(Color.BLACK);
		button_7.setBounds(993, 11, 132, 23);
		panel_2.add(button_7);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.GRAY);
		panel_3.setBounds(40, 126, 735, 466);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblItemCode = new JLabel("VehicleID");
		lblItemCode.setFont(new Font("Calibri", Font.BOLD, 25));
		lblItemCode.setBounds(42, 42, 166, 31);
		panel_3.add(lblItemCode);
		
		
		
		txtTrackId = new JTextField();
		
		txtTrackId.setFont(new Font("Calibri", Font.BOLD, 18));
		txtTrackId.setBounds(234, 44, 218, 31);
		panel_3.add(txtTrackId);
		
		
		
		
		txtTrackId.setColumns(10);
		
		JButton btnDelete = new JButton("SEARCH");
		btnDelete.setToolTipText("Delete");
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDelete.setBorder(null);
		btnDelete.setBackground(SystemColor.activeCaption);
		btnDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				searchProduct();
				
			}
		});
		btnDelete.setBounds(234, 371, 303, 50);
		
		panel_3.add(btnDelete);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(SystemColor.info);
		panel_4.setBounds(776, 126, 476, 466);
		panel.add(panel_4);
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_4 = new GroupLayout(panel_4);
		gl_panel_4.setHorizontalGroup(
			gl_panel_4.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
		);
		gl_panel_4.setVerticalGroup(
			gl_panel_4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_4.createSequentialGroup()
					.addGap(2)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE))
		);
		
		 table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Vehicle ID", "Vehicle Type", "VT_model", "engine_type", "enigne_displacement"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(85);
		table.getColumnModel().getColumn(1).setPreferredWidth(105);
		table.getColumnModel().getColumn(2).setPreferredWidth(95);
		table.getColumnModel().getColumn(3).setPreferredWidth(92);
		table.getColumnModel().getColumn(4).setPreferredWidth(147);
		
		scrollPane.setViewportView(table);
		panel_4.setLayout(gl_panel_4);
		
	}

}
