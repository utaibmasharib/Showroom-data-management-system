import java.io.ObjectInputStream.GetField;
import java.sql.*;

import javax.swing.JOptionPane;
public class ConnectDB {

	
	
	public static Connection DbConnect()
	{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=cars1;user=sa;password=asfa123");
			System.out.println("Connected");
			return con;
			
			
		}
		catch (Exception e) 
		{
			JOptionPane.showMessageDialog(null, "Error:"+e);
		}
		return null;
	}
	
	
	
}