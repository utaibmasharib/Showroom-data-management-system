import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class Customer extends JFrame {

	private JPanel contentPane;
	private JPanel panel_3;
	private JTextField txtCustomerId;
	private JTextField txtCustomerUpdate;
	private JTextField txtCNIC;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtAddress;
	private ConnectDB connect=new ConnectDB();
	private String query;
	private JTextField txtContact;
	private JTextField txtGender;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Customer frame = new Customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	public void searchRecord()
	{
		Connection conSr=connect.DbConnect();
		Statement stSr;
		ResultSet rsSr;
		try {
			stSr=conSr.createStatement();
			int id=Integer.parseInt(txtCustomerId.getText());
			query="select*FROM Customer WHERE customer_id='"+txtCustomerId.getText()+"'";
			rsSr=stSr.executeQuery(query);
			if(rsSr.next())
			{
				txtCustomerUpdate.setText(Integer.toString(rsSr.getInt("customer_id")));
				txtCNIC.setText(rsSr.getString("CNIC"));
				txtFirstName.setText(rsSr.getString("first_name"));
				txtLastName.setText(rsSr.getString("last_name"));
				txtAddress.setText(rsSr.getString("Address"));
				txtContact.setText(rsSr.getString("Contact_no"));
				txtGender.setText(rsSr.getString("gender"));
				txtEmail.setText(rsSr.getString("email"));
			}
			else
				JOptionPane.showMessageDialog(null, "ID:"+txtCustomerId.getText()+"is not existed");
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void updateRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="UPDATE Customer SET Customer_id='"+txtCustomerUpdate.getText()+"',first_name='"+txtFirstName.getText()+"',last_name='"+txtLastName.getText()+"',CNIC='"+txtCNIC.getText()+"',Address='"+txtAddress.getText()+"',Contact_no='"+txtContact.getText()+"',gender='"+txtGender.getText()+"',email='"+txtEmail.getText()+"'WHERE customer_id='"+txtCustomerUpdate.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Updated");
			else
				JOptionPane.showMessageDialog(null, "Unable to Update Record");
				
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void setToNull()
	{
		txtCustomerUpdate.setText("");
		txtAddress.setText("");
		txtLastName.setText("");
		txtCNIC.setText("");
		txtFirstName.setText("");
		txtGender.setText("");
		txtEmail.setText("");
		txtContact.setText("");
	}
	public void DeleteRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="DELETE FROM Customer WHERE customer_id='"+txtCustomerId.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Deleted");
			else
				JOptionPane.showMessageDialog(null, "Unable to Delete Record");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
		
	}
	public void addData()
	{
		Connection conAdd=connect.DbConnect();
		Statement stAdd;
		try{
			stAdd=conAdd.createStatement();
			query="INSERT INTO Customer VALUES ('"+txtCustomerUpdate.getText()+"','"+txtFirstName.getText()+"','"+txtLastName.getText()+"','"+txtCNIC.getText()+"','"+txtAddress.getText()+"','"+txtContact.getText()+"','"+txtGender.getText()+"','"+txtEmail.getText()+"')"; 
			boolean check=stAdd.execute(query);
			if(check==false)
			{
				JOptionPane.showMessageDialog(null, "Record Added Successfully");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Unable to ADD Record Successfully");	
			}
				
		} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "ERROR\n"+e);
			}
		}
	/**
	 * Create the frame.
	 */
	public Customer() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		//setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, screenWidth,screenHeight);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 1400, 800);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 31, 1267, 51);
		panel_2.setBackground(UIManager.getColor("TextField.foreground"));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton button = new JButton("Avaliable Vehicle");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AvaliableVehicle().setVisible(true);
				setVisible(false);
			}
		});
		button.setToolTipText("Register");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Calibri", Font.BOLD, 15));
		button.setBorder(null);
		button.setBackground(Color.BLACK);
		button.setBounds(10, 11, 115, 23);
		panel_2.add(button);
		
		JButton button_1 = new JButton("Delivery");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Delivery().setVisible(true);
				setVisible(false);
			}
		});
		button_1.setToolTipText("Track");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Calibri", Font.BOLD, 15));
		button_1.setBorder(null);
		button_1.setBackground(Color.BLACK);
		button_1.setBounds(135, 11, 132, 23);
		panel_2.add(button_1);
		
		JButton button_2 = new JButton("Vehicle");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Vehicle().setVisible(true);
				setVisible(false);
			}
		});
		button_2.setToolTipText("Track");
		button_2.setForeground(Color.WHITE);
		button_2.setFont(new Font("Calibri", Font.BOLD, 15));
		button_2.setBorder(null);
		button_2.setBackground(Color.BLACK);
		button_2.setBounds(277, 11, 138, 23);
		panel_2.add(button_2);
		
		JButton button_3 = new JButton("Supplier");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Supplier().setVisible(true);
				setVisible(false);
			}
		});
		button_3.setToolTipText("Track");
		button_3.setForeground(Color.WHITE);
		button_3.setFont(new Font("Calibri", Font.BOLD, 15));
		button_3.setBorder(null);
		button_3.setBackground(Color.BLACK);
		button_3.setBounds(425, 11, 126, 23);
		panel_2.add(button_3);
		
		JButton btnEmployee = new JButton("Employee");
		btnEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Employee().setVisible(true);
				setVisible(false);
			}
		});
		btnEmployee.setToolTipText("Track");
		btnEmployee.setForeground(Color.WHITE);
		btnEmployee.setFont(new Font("Calibri", Font.BOLD, 15));
		btnEmployee.setBorder(null);
		btnEmployee.setBackground(Color.BLACK);
		btnEmployee.setBounds(561, 11, 138, 23);
		panel_2.add(btnEmployee);
		
		JButton button_5 = new JButton("Show Room");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Show_Room().setVisible(true);
				setVisible(false);
			}
		});
		button_5.setToolTipText("Track");
		button_5.setForeground(Color.WHITE);
		button_5.setFont(new Font("Calibri", Font.BOLD, 15));
		button_5.setBorder(null);
		button_5.setBackground(Color.BLACK);
		button_5.setBounds(709, 11, 132, 23);
		panel_2.add(button_5);
		
		JButton button_6 = new JButton("Order");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Order().setVisible(true);
				setVisible(false);
			}
		});
		button_6.setToolTipText("Track");
		button_6.setForeground(Color.WHITE);
		button_6.setFont(new Font("Calibri", Font.BOLD, 15));
		button_6.setBorder(null);
		button_6.setBackground(Color.BLACK);
		button_6.setBounds(851, 11, 132, 23);
		panel_2.add(button_6);
		
		JButton button_7 = new JButton("Payment");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Payment().setVisible(true);
				setVisible(false);
			}
		});
		button_7.setToolTipText("Track");
		button_7.setForeground(Color.WHITE);
		button_7.setFont(new Font("Calibri", Font.BOLD, 15));
		button_7.setBorder(null);
		button_7.setBackground(Color.BLACK);
		button_7.setBounds(993, 11, 132, 23);
		panel_2.add(button_7);
		
		panel_3 = new JPanel();
		panel_3.setBounds(10, 104, 1240, 546);
		panel_3.setBackground(Color.GRAY);
		panel_3.setFont(new Font("Calibri", Font.BOLD, 18));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Customer ID");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(28, 29, 199, 31);
		panel_3.add(lblNewLabel);
		
		txtCustomerId = new JTextField();
		txtCustomerId.setBounds(237, 29, 186, 31);
		panel_3.add(txtCustomerId);
		txtCustomerId.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			searchRecord();
				
			}
		});
		txtCustomerId.setColumns(10);
		
		JLabel lblVehicleId = new JLabel("Customer ID");
		lblVehicleId.setFont(new Font("Calibri", Font.BOLD, 25));
		lblVehicleId.setBounds(332, 114, 151, 31);
		panel_3.add(lblVehicleId);
		
		JLabel lblUpdateRecord = new JLabel("MANAGE RECORD");
		lblUpdateRecord.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUpdateRecord.setBounds(540, 71, 216, 31);
		panel_3.add(lblUpdateRecord);
		
		txtCustomerUpdate = new JTextField();
		txtCustomerUpdate.setColumns(10);
		txtCustomerUpdate.setBounds(332, 156, 216, 31);
		panel_3.add(txtCustomerUpdate);
		
		JLabel lblPackageName = new JLabel("CNIC");
		lblPackageName.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPackageName.setBounds(695, 114, 151, 31);
		panel_3.add(lblPackageName);
		
		txtCNIC = new JTextField();
		txtCNIC.setColumns(10);
		txtCNIC.setBounds(695, 156, 186, 31);
		panel_3.add(txtCNIC);
		
		JLabel lblLocation = new JLabel("FirstName");
		lblLocation.setFont(new Font("Calibri", Font.BOLD, 25));
		lblLocation.setBounds(332, 195, 109, 31);
		panel_3.add(lblLocation);
		
		JLabel lblStatus = new JLabel("LastName");
		lblStatus.setFont(new Font("Calibri", Font.BOLD, 25));
		lblStatus.setBounds(695, 198, 127, 31);
		panel_3.add(lblStatus);
		
		txtFirstName = new JTextField();
		txtFirstName.setColumns(10);
		txtFirstName.setBounds(332, 224, 216, 31);
		panel_3.add(txtFirstName);
		
		txtLastName = new JTextField();
		txtLastName.setColumns(10);
		txtLastName.setBounds(695, 224, 186, 31);
		panel_3.add(txtLastName);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(332, 291, 216, 31);
		panel_3.add(txtAddress);
		
		JLabel lblUser = new JLabel("Address");
		lblUser.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUser.setBounds(332, 266, 230, 31);
		panel_3.add(lblUser);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addData();
				setToNull();
			}
		});
		btnAdd.setToolTipText("Delete");
		btnAdd.setFont(new Font("Calibri", Font.BOLD, 25));
		btnAdd.setBorder(null);
		btnAdd.setBackground(SystemColor.activeCaption);
		btnAdd.setBounds(189, 480, 202, 51);
		panel_3.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateRecord();
				setToNull();
			}
		});
		btnUpdate.setToolTipText("Delete");
		btnUpdate.setFont(new Font("Calibri", Font.BOLD, 25));
		btnUpdate.setBorder(null);
		btnUpdate.setBackground(SystemColor.activeCaption);
		btnUpdate.setBounds(450, 480, 202, 51);
		panel_3.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteRecord();
				setToNull();
			}
		});
		btnDelete.setToolTipText("Delete");
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDelete.setBorder(null);
		btnDelete.setBackground(SystemColor.activeCaption);
		btnDelete.setBounds(714, 480, 202, 51);
		panel_3.add(btnDelete);
		
		JLabel lblContact = new JLabel("Contact No.");
		lblContact.setFont(new Font("Calibri", Font.BOLD, 25));
		lblContact.setBounds(695, 266, 151, 31);
		panel_3.add(lblContact);
		
		txtContact = new JTextField();
		txtContact.setColumns(10);
		txtContact.setBounds(695, 291, 186, 31);
		panel_3.add(txtContact);
		
		JLabel lblJobTitle = new JLabel("Gender");
		lblJobTitle.setFont(new Font("Calibri", Font.BOLD, 25));
		lblJobTitle.setBounds(332, 333, 230, 31);
		panel_3.add(lblJobTitle);
		
		JLabel lblSalart = new JLabel("E-mail");
		lblSalart.setFont(new Font("Calibri", Font.BOLD, 25));
		lblSalart.setBounds(695, 333, 151, 31);
		panel_3.add(lblSalart);
		
		txtGender = new JTextField();
		txtGender.setColumns(10);
		txtGender.setBounds(332, 363, 216, 31);
		panel_3.add(txtGender);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(695, 363, 186, 31);
		panel_3.add(txtEmail);
	}

}
