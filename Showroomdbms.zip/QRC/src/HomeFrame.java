import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class HomeFrame extends JFrame {

	private JPanel contentPane;
	private JPasswordField txtPassword;
	private ConnectDB connect=new ConnectDB();
	private String query;
	private JTextField txtUsername;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeFrame frame = new HomeFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomeFrame() 
	{
		initialize();
		
	}
	public void initialize()
	{
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 317, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 317, 408);
		panel.setBackground(Color.GRAY);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel AccountLabel = new JLabel("Account Login");
		AccountLabel.setForeground(SystemColor.textHighlight);
		AccountLabel.setFont(new Font("Calibri", Font.BOLD, 30));
		AccountLabel.setBounds(76, 52, 175, 30);
		panel.add(AccountLabel);
		
		JLabel lblUserName = new JLabel("User Name");
		lblUserName.setForeground(SystemColor.activeCaptionBorder);
		lblUserName.setFont(new Font("Calibri", Font.BOLD, 20));
		lblUserName.setBounds(64, 101, 134, 22);
		panel.add(lblUserName);
		
		txtUsername = new JTextField();
		txtUsername.setToolTipText("User Name");
		txtUsername.setFont(new Font("Calibri", Font.PLAIN, 14));
		txtUsername.setBounds(64, 134, 187, 22);
		txtUsername.setColumns(10);
		
		txtUsername.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) 
			{
				if(e.getKeyCode()==KeyEvent.VK_ENTER)
				{
					txtPassword.requestFocus();
				}
				
				
			}
		});
		panel.add(txtUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(SystemColor.activeCaptionBorder);
		lblPassword.setBackground(SystemColor.desktop);
		lblPassword.setFont(new Font("Calibri", Font.BOLD, 20));
		lblPassword.setBounds(64, 167, 92, 25);
		panel.add(lblPassword);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtPassword.setToolTipText("Password");
		txtPassword.setColumns(10);
		txtPassword.setBounds(64, 203, 187, 22);
		panel.add(txtPassword);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setToolTipText("Login Here");
		btnLogin.setForeground(SystemColor.textHighlight);
		btnLogin.setBackground(SystemColor.activeCaptionBorder);
		btnLogin.setFont(new Font("Calibri", Font.BOLD, 20));
		btnLogin.setBounds(64, 270, 187, 46);
		btnLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				matchData();
			}
		});
		panel.add(btnLogin);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.ORANGE);
		panel_1.setBounds(0, 0, 317, 36);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton closeBtn = new JButton("X");
		closeBtn.setAutoscrolls(true);
		closeBtn.setBorder(null);
		closeBtn.setBackground(new Color(255, 0, 0));
		closeBtn.setFont(new Font("Calibri", Font.BOLD, 14));
		closeBtn.setBounds(272, 0, 45, 36);
		closeBtn.setToolTipText("Exit");
		closeBtn.addActionListener(new ActionListener() 
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				setDefaultCloseOperation(EXIT_ON_CLOSE);
				setVisible(false);
			}
		});
		panel_1.add(closeBtn);
		
		JButton minimizeBtn = new JButton("-");
		minimizeBtn.setBorder(null);
		minimizeBtn.setToolTipText("Minimize");
		minimizeBtn.setBackground(SystemColor.textHighlight);
		minimizeBtn.setFont(new Font("Calibri", Font.BOLD, 14));
		minimizeBtn.setBounds(231, 0, 45, 36);
		minimizeBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				setState(Frame.ICONIFIED);
			}
		});
		panel_1.add(minimizeBtn);
		
	}
	public void matchData()
	{
		Connection con=connect.DbConnect();
		Statement st;
		ResultSet rs;
		try {
			st=con.createStatement();
			query="Select*from login where username='"+txtUsername.getText()+"'and passcode='"+txtPassword.getText()+"'";
			rs=st.executeQuery(query);
			if(rs.next())
			{
				new Vehicle().setVisible(true);
				setVisible(false);
			}
			else
				JOptionPane.showMessageDialog(null,"Invalid Credientials!");
				
			
		} catch (SQLException e) {
			
			JOptionPane.showMessageDialog(null,"Error occured while executing query"+e);
		}
		
		
	}

}
