import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class Order extends JFrame {

	private JPanel contentPane;
	private JPanel panel_3;
	private JTextField txtOrderId;
	private JTextField txtOrderDate;
	private JTextField txtOrderUpdate;
	private JTextField txtRequiredDate;
	private JTextField txtShippedDate;
	private JTextField txtQuantity;
	private JTextField txtPrice;
	private ConnectDB connect=new ConnectDB();
	private String query;
	private JTextField txtVehicle;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Order frame = new Order();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void searchRecord()
	{
		Connection conSr=connect.DbConnect();
		Statement stSr;
		ResultSet rsSr;
		try {
			stSr=conSr.createStatement();
			int id=Integer.parseInt(txtOrderId.getText());
			query="select*FROM orderr WHERE orderr_id='"+txtOrderId.getText()+"'";
			rsSr=stSr.executeQuery(query);
			if(rsSr.next())
			{
				txtOrderUpdate.setText(Integer.toString(rsSr.getInt("orderr_id")));
				txtOrderDate.setText(rsSr.getString("order_date"));
				txtRequiredDate.setText(rsSr.getString("required_date"));
				txtShippedDate.setText(rsSr.getString("shipped_date"));
				txtQuantity.setText(rsSr.getString("quantity"));
				txtPrice.setText(rsSr.getString("price"));
			}
			else
				JOptionPane.showMessageDialog(null, "ID:"+txtOrderId.getText()+"is not existed");
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void updateRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="UPDATE orderr SET orderr_id='"+txtOrderUpdate.getText()+"',order_date='"+txtOrderDate.getText()+"',required_date='"+txtRequiredDate.getText()+"',shipped_date='"+txtShippedDate.getText()+"',quantity='"+txtQuantity.getText()+"',price='"+txtPrice.getText()+"'WHERE orderrr_id='"+txtOrderUpdate.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Updated");
			else
				JOptionPane.showMessageDialog(null, "Unable to Update Record");
				
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void setToNull()
	{
		txtOrderUpdate.setText("");
		txtOrderDate.setText("");
		txtRequiredDate.setText("");
		txtShippedDate.setText("");
		txtQuantity.setText("");
		txtPrice.setText("");
	}
	public void DeleteRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="DELETE FROM orderr WHERE orderr_id='"+txtOrderId.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Deleted");
			else
				JOptionPane.showMessageDialog(null, "Unable to Delete Record");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
		
	}
	public void addData()
	{
		Connection conAdd=connect.DbConnect();
		Statement stAdd;
		try{
			stAdd=conAdd.createStatement();
			query="INSERT INTO orderr VALUES ('"+txtOrderUpdate.getText()+"','"+txtOrderDate.getText()+"','"+txtRequiredDate.getText()+"','"+txtShippedDate.getText()+"','"+txtQuantity.getText()+"','"+txtPrice.getText()+"')"; 
			boolean check=stAdd.execute(query);
			if(check==false)
			{
				JOptionPane.showMessageDialog(null, "Record Added Successfully");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Unable to ADD Record Successfully");	
			}
				
		} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "ERROR\n"+e);
			}
		}

	/**
	 * Create the frame.
	 */
	public Order() {
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		//setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, screenWidth,screenHeight);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 1400, 800);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 31, 1267, 51);
		panel_2.setBackground(UIManager.getColor("TextField.foreground"));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton button = new JButton("Avaliable Vehicle");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AvaliableVehicle().setVisible(true);
				setVisible(false);
			}
		});
		button.setToolTipText("Register");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Calibri", Font.BOLD, 15));
		button.setBorder(null);
		button.setBackground(Color.BLACK);
		button.setBounds(10, 11, 115, 23);
		panel_2.add(button);
		
		JButton button_1 = new JButton("Delivery");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Delivery().setVisible(true);
				setVisible(false);
			}
		});
		button_1.setToolTipText("Track");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Calibri", Font.BOLD, 15));
		button_1.setBorder(null);
		button_1.setBackground(Color.BLACK);
		button_1.setBounds(135, 11, 132, 23);
		panel_2.add(button_1);
		
		JButton button_2 = new JButton("Vehicle");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Vehicle().setVisible(true);
				setVisible(false);
			}
		});
		button_2.setToolTipText("Track");
		button_2.setForeground(Color.WHITE);
		button_2.setFont(new Font("Calibri", Font.BOLD, 15));
		button_2.setBorder(null);
		button_2.setBackground(Color.BLACK);
		button_2.setBounds(277, 11, 138, 23);
		panel_2.add(button_2);
		
		JButton btnCustomer = new JButton("Customer");
		btnCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Customer().setVisible(true);
				setVisible(false);
			}
		});
		btnCustomer.setToolTipText("Track");
		btnCustomer.setForeground(Color.WHITE);
		btnCustomer.setFont(new Font("Calibri", Font.BOLD, 15));
		btnCustomer.setBorder(null);
		btnCustomer.setBackground(Color.BLACK);
		btnCustomer.setBounds(425, 11, 126, 23);
		panel_2.add(btnCustomer);
		
		JButton button_4 = new JButton("Employee");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Employee().setVisible(true);
				setVisible(false);
			}
		});
		button_4.setToolTipText("Track");
		button_4.setForeground(Color.WHITE);
		button_4.setFont(new Font("Calibri", Font.BOLD, 15));
		button_4.setBorder(null);
		button_4.setBackground(Color.BLACK);
		button_4.setBounds(561, 11, 138, 23);
		panel_2.add(button_4);
		
		JButton button_5 = new JButton("Show Room");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Show_Room().setVisible(true);
				setVisible(false);
			}
		});
		button_5.setToolTipText("Track");
		button_5.setForeground(Color.WHITE);
		button_5.setFont(new Font("Calibri", Font.BOLD, 15));
		button_5.setBorder(null);
		button_5.setBackground(Color.BLACK);
		button_5.setBounds(709, 11, 132, 23);
		panel_2.add(button_5);
		
		JButton button_6 = new JButton("Order");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Order().setVisible(true);
				setVisible(false);
			}
		});
		button_6.setToolTipText("Track");
		button_6.setForeground(Color.WHITE);
		button_6.setFont(new Font("Calibri", Font.BOLD, 15));
		button_6.setBorder(null);
		button_6.setBackground(Color.BLACK);
		button_6.setBounds(851, 11, 132, 23);
		panel_2.add(button_6);
		
		JButton button_7 = new JButton("Payment");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Payment().setVisible(true);
				setVisible(false);
			}
		});
		button_7.setToolTipText("Track");
		button_7.setForeground(Color.WHITE);
		button_7.setFont(new Font("Calibri", Font.BOLD, 15));
		button_7.setBorder(null);
		button_7.setBackground(Color.BLACK);
		button_7.setBounds(993, 11, 132, 23);
		panel_2.add(button_7);
		
		panel_3 = new JPanel();
		panel_3.setBounds(10, 104, 1240, 546);
		panel_3.setBackground(Color.GRAY);
		panel_3.setFont(new Font("Calibri", Font.BOLD, 18));
		panel.add(panel_3);
		panel_3.setLayout(null);
		JLabel lblNewLabel = new JLabel("Enter Order ID");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(28, 29, 199, 31);
		panel_3.add(lblNewLabel);
		
		txtOrderId = new JTextField();
		txtOrderId.setBounds(237, 29, 186, 31);
		panel_3.add(txtOrderId);
		txtOrderId.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			searchRecord();
				
			}
		});
		txtOrderId.setColumns(10);
		
		JLabel lblVehicleId = new JLabel("Order ID");
		lblVehicleId.setFont(new Font("Calibri", Font.BOLD, 25));
		lblVehicleId.setBounds(332, 114, 151, 31);
		panel_3.add(lblVehicleId);
		
		JLabel lblUpdateRecord = new JLabel("MANAGE RECORD");
		lblUpdateRecord.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUpdateRecord.setBounds(540, 71, 216, 31);
		panel_3.add(lblUpdateRecord);
		
		txtOrderUpdate = new JTextField();
		txtOrderUpdate.setColumns(10);
		txtOrderUpdate.setBounds(332, 156, 216, 31);
		panel_3.add(txtOrderUpdate);
		
		JLabel lblPackageName = new JLabel("order_date");
		lblPackageName.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPackageName.setBounds(695, 114, 151, 31);
		panel_3.add(lblPackageName);
		
		txtOrderDate = new JTextField();
		txtOrderDate.setColumns(10);
		txtOrderDate.setBounds(695, 156, 186, 31);
		panel_3.add(txtOrderDate);
		
		JLabel lblLocation = new JLabel("required_date");
		lblLocation.setFont(new Font("Calibri", Font.BOLD, 25));
		lblLocation.setBounds(332, 227, 109, 31);
		panel_3.add(lblLocation);
		
		JLabel lblStatus = new JLabel("Shipped Date");
		lblStatus.setFont(new Font("Calibri", Font.BOLD, 25));
		lblStatus.setBounds(693, 227, 127, 31);
		panel_3.add(lblStatus);
		
		txtRequiredDate = new JTextField();
		txtRequiredDate.setColumns(10);
		txtRequiredDate.setBounds(332, 269, 216, 31);
		panel_3.add(txtRequiredDate);
		
		txtShippedDate = new JTextField();
		txtShippedDate.setColumns(10);
		txtShippedDate.setBounds(695, 269, 186, 31);
		panel_3.add(txtShippedDate);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(332, 353, 216, 31);
		panel_3.add(txtQuantity);
		
		JLabel lblUser = new JLabel("Quantity");
		lblUser.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUser.setBounds(332, 311, 230, 31);
		panel_3.add(lblUser);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addData();
				setToNull();
			}
		});
		btnAdd.setToolTipText("Delete");
		btnAdd.setFont(new Font("Calibri", Font.BOLD, 25));
		btnAdd.setBorder(null);
		btnAdd.setBackground(SystemColor.activeCaption);
		btnAdd.setBounds(189, 480, 202, 51);
		panel_3.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateRecord();
				setToNull();
			}
		});
		btnUpdate.setToolTipText("Delete");
		btnUpdate.setFont(new Font("Calibri", Font.BOLD, 25));
		btnUpdate.setBorder(null);
		btnUpdate.setBackground(SystemColor.activeCaption);
		btnUpdate.setBounds(450, 480, 202, 51);
		panel_3.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteRecord();
				setToNull();
			}
		});
		btnDelete.setToolTipText("Delete");
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDelete.setBorder(null);
		btnDelete.setBackground(SystemColor.activeCaption);
		btnDelete.setBounds(714, 480, 202, 51);
		panel_3.add(btnDelete);
		
		JLabel lblContact = new JLabel("Price");
		lblContact.setFont(new Font("Calibri", Font.BOLD, 25));
		lblContact.setBounds(695, 311, 151, 31);
		panel_3.add(lblContact);
		
		txtPrice = new JTextField();
		txtPrice.setColumns(10);
		txtPrice.setBounds(695, 353, 186, 31);
		panel_3.add(txtPrice);
	}

}
