
public class Packages 
{
	private int vehicleID;
	private String vehicleType,vtModel,engine,displacement;
	public Packages(int vehicleID, String vehicleType, String vtModel, String enigne, String displacement) {
		
		this.vehicleID = vehicleID;
		this.vehicleType = vehicleType;
		this.vtModel = vtModel;
		this.engine = enigne;
		this.displacement = displacement;
	}
	public int getVehicleID() {
		return vehicleID;
	}
	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getVtModel() {
		return vtModel;
	}
	public void setVtModel(String vtModel) {
		this.vtModel = vtModel;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getDisplacement() {
		return displacement;
	}
	public void setDisplacement(String displacement) {
		this.displacement = displacement;
	}
	public Packages() 
	{
		this.vehicleID=0;
		this.vtModel="";
		this.vehicleType="";
		this.displacement="";
		this.engine="";
		
	
	}
	

}
