import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class Show_Room extends JFrame {

	private JPanel contentPane;
	private JPanel panel_3;
	private JTextField txtShowroomId;
	private JTextField txtShowroomUpdate;
	private JTextField txtName;
	private JTextField txtContact;
	private JTextField txtAddress;
	private ConnectDB connect=new ConnectDB();
	private String query;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Show_Room frame = new Show_Room();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void searchRecord()
	{
		Connection conSr=connect.DbConnect();
		Statement stSr;
		ResultSet rsSr;
		try {
			stSr=conSr.createStatement();
			int id=Integer.parseInt(txtShowroomId.getText());
			query="select*FROM show_room WHERE showroom_id='"+txtShowroomId.getText()+"'";
			rsSr=stSr.executeQuery(query);
			if(rsSr.next())
			{
				txtShowroomUpdate.setText(Integer.toString(rsSr.getInt("showroom_id")));
				txtName.setText(rsSr.getString("Name"));
				txtContact.setText(rsSr.getString("Contact_no"));
				txtAddress.setText(rsSr.getString("Addres"));
			}
			else
				JOptionPane.showMessageDialog(null, "ID:"+txtShowroomId.getText()+"is not existed");
			
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void updateRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="UPDATE show_room SET Name='"+txtName.getText()+"',Addres='"+txtAddress.getText()+"',Contact_no='"+txtContact.getText()+"',showroom_id='"+txtShowroomUpdate.getText()+"'WHERE showroom_id='"+txtShowroomUpdate.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Updated");
			else
				JOptionPane.showMessageDialog(null, "Unable to Update Record");
				
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void setToNull()
	{
		txtShowroomUpdate.setText("");
		txtName.setText("");
		txtAddress.setText("");
		txtContact.setText("");
	}
	public void DeleteRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="DELETE FROM show_room WHERE showroom_id='"+txtShowroomId.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Deleted");
			else
				JOptionPane.showMessageDialog(null, "Unable to Delete Record");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
		
	}
	public void addData()
	{
		Connection conAdd=connect.DbConnect();
		Statement stAdd;
		try{
			stAdd=conAdd.createStatement();
			query="INSERT INTO show_room VALUES ('"+txtName.getText()+"','"+txtAddress.getText()+"','"+txtContact.getText()+"','"+txtShowroomUpdate.getText()+"')"; 
			boolean check=stAdd.execute(query);
			if(check==false)
			{
				JOptionPane.showMessageDialog(null, "Record Added Successfully");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Unable to ADD Record Successfully");	
			}
				
		} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "ERROR\n"+e);
			}
		}

	/**
	 * Create the frame.
	 */
	public Show_Room() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		//setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, screenWidth,screenHeight);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 1400, 800);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 31, 1267, 51);
		panel_2.setBackground(UIManager.getColor("TextField.foreground"));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton button = new JButton("Avaliable Vehicle");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AvaliableVehicle().setVisible(true);
				setVisible(false);
			}
		});
		button.setToolTipText("Register");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Calibri", Font.BOLD, 15));
		button.setBorder(null);
		button.setBackground(Color.BLACK);
		button.setBounds(10, 11, 115, 23);
		panel_2.add(button);
		
		JButton button_1 = new JButton("Delivery");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Delivery().setVisible(true);
				setVisible(false);
			}
		});
		button_1.setToolTipText("Track");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Calibri", Font.BOLD, 15));
		button_1.setBorder(null);
		button_1.setBackground(Color.BLACK);
		button_1.setBounds(135, 11, 132, 23);
		panel_2.add(button_1);
		
		JButton button_2 = new JButton("Vehicle");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Vehicle().setVisible(true);
				setVisible(false);
			}
		});
		button_2.setToolTipText("Track");
		button_2.setForeground(Color.WHITE);
		button_2.setFont(new Font("Calibri", Font.BOLD, 15));
		button_2.setBorder(null);
		button_2.setBackground(Color.BLACK);
		button_2.setBounds(277, 11, 138, 23);
		panel_2.add(button_2);
		
		JButton button_3 = new JButton("Customer");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Customer().setVisible(true);
				setVisible(false);
			}
		});
		button_3.setToolTipText("Track");
		button_3.setForeground(Color.WHITE);
		button_3.setFont(new Font("Calibri", Font.BOLD, 15));
		button_3.setBorder(null);
		button_3.setBackground(Color.BLACK);
		button_3.setBounds(425, 11, 126, 23);
		panel_2.add(button_3);
		
		JButton button_4 = new JButton("Employee");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Employee().setVisible(true);
				setVisible(false);
			}
		});
		button_4.setToolTipText("Track");
		button_4.setForeground(Color.WHITE);
		button_4.setFont(new Font("Calibri", Font.BOLD, 15));
		button_4.setBorder(null);
		button_4.setBackground(Color.BLACK);
		button_4.setBounds(561, 11, 138, 23);
		panel_2.add(button_4);
		
		JButton btnSuppkier = new JButton("Supplier");
		btnSuppkier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Supplier().setVisible(true);
				setVisible(false);
			}
		});
		btnSuppkier.setToolTipText("Track");
		btnSuppkier.setForeground(Color.WHITE);
		btnSuppkier.setFont(new Font("Calibri", Font.BOLD, 15));
		btnSuppkier.setBorder(null);
		btnSuppkier.setBackground(Color.BLACK);
		btnSuppkier.setBounds(709, 11, 132, 23);
		panel_2.add(btnSuppkier);
		
		JButton button_6 = new JButton("Order");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Order().setVisible(true);
				setVisible(false);
			}
		});
		button_6.setToolTipText("Track");
		button_6.setForeground(Color.WHITE);
		button_6.setFont(new Font("Calibri", Font.BOLD, 15));
		button_6.setBorder(null);
		button_6.setBackground(Color.BLACK);
		button_6.setBounds(851, 11, 132, 23);
		panel_2.add(button_6);
		
		JButton button_7 = new JButton("Payment");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Payment().setVisible(true);
				setVisible(false);
			}
		});
		button_7.setToolTipText("Track");
		button_7.setForeground(Color.WHITE);
		button_7.setFont(new Font("Calibri", Font.BOLD, 15));
		button_7.setBorder(null);
		button_7.setBackground(Color.BLACK);
		button_7.setBounds(993, 11, 132, 23);
		panel_2.add(button_7);
		
		panel_3 = new JPanel();
		panel_3.setBounds(10, 104, 1240, 546);
		panel_3.setBackground(Color.GRAY);
		panel_3.setFont(new Font("Calibri", Font.BOLD, 18));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter ShowRoom ID");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(28, 29, 218, 31);
		panel_3.add(lblNewLabel);
		
		txtShowroomId = new JTextField();
		txtShowroomId.setBounds(256, 29, 186, 31);
		panel_3.add(txtShowroomId);
		txtShowroomId.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			searchRecord();
				
			}
		});
		txtShowroomId.setColumns(10);
		
		JLabel lblVehicleId = new JLabel("ShowRoom ID");
		lblVehicleId.setFont(new Font("Calibri", Font.BOLD, 25));
		lblVehicleId.setBounds(332, 114, 151, 31);
		panel_3.add(lblVehicleId);
		
		JLabel lblUpdateRecord = new JLabel("MANAGE RECORD");
		lblUpdateRecord.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUpdateRecord.setBounds(540, 71, 216, 31);
		panel_3.add(lblUpdateRecord);
		
		txtShowroomUpdate = new JTextField();
		txtShowroomUpdate.setColumns(10);
		txtShowroomUpdate.setBounds(332, 156, 216, 31);
		panel_3.add(txtShowroomUpdate);
		
		JLabel lblPackageName = new JLabel("Name");
		lblPackageName.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPackageName.setBounds(695, 114, 151, 31);
		panel_3.add(lblPackageName);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(695, 156, 186, 31);
		panel_3.add(txtName);
		
		JLabel lblLocation = new JLabel("Contact No.");
		lblLocation.setFont(new Font("Calibri", Font.BOLD, 25));
		lblLocation.setBounds(332, 281, 151, 31);
		panel_3.add(lblLocation);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Calibri", Font.BOLD, 25));
		lblAddress.setBounds(695, 281, 127, 31);
		panel_3.add(lblAddress);
		
		txtContact = new JTextField();
		txtContact.setColumns(10);
		txtContact.setBounds(332, 323, 216, 31);
		panel_3.add(txtContact);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(695, 323, 186, 31);
		panel_3.add(txtAddress);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addData();
				setToNull();
			}
		});
		btnAdd.setToolTipText("Delete");
		btnAdd.setFont(new Font("Calibri", Font.BOLD, 25));
		btnAdd.setBorder(null);
		btnAdd.setBackground(SystemColor.activeCaption);
		btnAdd.setBounds(189, 480, 202, 51);
		panel_3.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateRecord();
				setToNull();
			}
		});
		btnUpdate.setToolTipText("Delete");
		btnUpdate.setFont(new Font("Calibri", Font.BOLD, 25));
		btnUpdate.setBorder(null);
		btnUpdate.setBackground(SystemColor.activeCaption);
		btnUpdate.setBounds(450, 480, 202, 51);
		panel_3.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteRecord();
				setToNull();
			}
		});
		btnDelete.setToolTipText("Delete");
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDelete.setBorder(null);
		btnDelete.setBackground(SystemColor.activeCaption);
		btnDelete.setBounds(714, 480, 202, 51);
		panel_3.add(btnDelete);
	}

}
