import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.JobAttributes;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Vehicle extends JFrame {

	private JPanel contentPane;
	private JPanel panel_3;
	private JTextField txtOrderId;
	private JTextField txtOrderUpdate;
	private JTextField txtVehicleType;
	private JTextField txtVTModel;
	private JTextField txtEngineType;
	private JTextField txtEngineDisplacement;
	private ConnectDB connect=new ConnectDB();
	private String query;
	private JTextField textVehicleColor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vehicle frame = new Vehicle();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void searchRecord()
	{
		Connection conSr=connect.DbConnect();
		Statement stSr;
		ResultSet rsSr;
		try {
			stSr=conSr.createStatement();
			int id=Integer.parseInt(txtOrderId.getText());
			query="select*FROM vehicle WHERE vehicle_id='"+txtOrderId.getText()+"'";
			rsSr=stSr.executeQuery(query);
			if(rsSr.next())
			{
				txtOrderUpdate.setText(Integer.toString(rsSr.getInt("vehicle_id")));
				txtVehicleType.setText(rsSr.getString("vehicle_type"));
				txtVTModel.setText(rsSr.getString("VT_model"));
				txtEngineType.setText(rsSr.getString("engine_type"));
				txtEngineDisplacement.setText(rsSr.getString("engine_displacement"));
				textVehicleColor.setText(rsSr.getString("vehicle_color"));
			}
			else
				JOptionPane.showMessageDialog(null, "ID:"+txtOrderId.getText()+"is not existed");
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void updateRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="UPDATE vehicle SET vehicle_id='"+txtOrderUpdate.getText()+"',vehicle_type='"+txtVehicleType.getText()+"',VT_model='"+txtVTModel.getText()+"',engine_type='"+txtEngineType.getText()+"',vehicle_color='"+textVehicleColor.getText()+"',engine_displacement='"+txtEngineDisplacement.getText()+"'WHERE vehicle_id='"+txtOrderId.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Updated");
			else
				JOptionPane.showMessageDialog(null, "Unable to Update Record");
				
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
	}
	public void setToNull()
	{
		txtOrderUpdate.setText("");
		txtEngineDisplacement.setText("");
		txtEngineType.setText("");
		txtVehicleType.setText("");
		txtVTModel.setText("");
		textVehicleColor.setText("");
	}
	public void DeleteRecord()
	{
		Connection con=connect.DbConnect();
		Statement st;
		
		try {
			st=con.createStatement();
			query="DELETE FROM VEHICLE WHERE vehicle_id='"+txtOrderId.getText()+"'";
			boolean check=st.execute(query);
			if(check==false)
				JOptionPane.showMessageDialog(null, "Record Deleted");
			else
				JOptionPane.showMessageDialog(null, "Unable to Delete Record");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Error: ID not found");
		}
		
	}
	public void addData()
	{
		Connection conAdd=connect.DbConnect();
		Statement stAdd;
		try{
			stAdd=conAdd.createStatement();
			query="INSERT INTO vehicle VALUES ('"+txtOrderUpdate.getText()+"','"+txtVehicleType.getText()+"','"+txtVTModel.getText()+"','"+txtEngineType.getText()+"','"+textVehicleColor.getText()+"','"+txtEngineDisplacement.getText()+"')"; 
			boolean check=stAdd.execute(query);
			if(check==false)
			{
				JOptionPane.showMessageDialog(null, "Record Added Successfully");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Unable to ADD Record Successfully");	
			}
				
		} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "ERROR\n"+e);
			}
		}
	public Vehicle() {
		initialize();
		
	}
	public void initialize()
	{
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		//setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, screenWidth,screenHeight);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 1400, 800);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 31, 1267, 51);
		panel_2.setBackground(UIManager.getColor("TextField.foreground"));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnNewRecord = new JButton("EMPLOYEE");
		btnNewRecord.setToolTipText("Register");
		btnNewRecord.setBorder(null);
		btnNewRecord.setFont(new Font("Calibri", Font.BOLD, 15));
		btnNewRecord.setBackground(Color.BLACK);
		btnNewRecord.setForeground(Color.WHITE);
		btnNewRecord.setBounds(10, 11, 115, 23);
		btnNewRecord.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				new Employee().setVisible(true);
				setVisible(false);
			}
		});
		panel_2.add(btnNewRecord);
		
		JButton btnTrack = new JButton("Delivery");
		btnTrack.setToolTipText("Track");
		btnTrack.setForeground(Color.WHITE);
		btnTrack.setFont(new Font("Calibri", Font.BOLD, 15));
		btnTrack.setBorder(null);
		btnTrack.setBackground(Color.BLACK);
		btnTrack.setBounds(135, 11, 132, 23);
		btnTrack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Delivery().setVisible(true);
				setVisible(false);
				
			}
		});
		panel_2.add(btnTrack);
		
		JButton btnAvaliableVehicle = new JButton("Avaliable Vehicle");
		btnAvaliableVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AvaliableVehicle().setVisible(true);
				setVisible(false);
			}
		});
		btnAvaliableVehicle.setToolTipText("Track");
		btnAvaliableVehicle.setForeground(Color.WHITE);
		btnAvaliableVehicle.setFont(new Font("Calibri", Font.BOLD, 15));
		btnAvaliableVehicle.setBorder(null);
		btnAvaliableVehicle.setBackground(Color.BLACK);
		btnAvaliableVehicle.setBounds(277, 11, 138, 23);
		panel_2.add(btnAvaliableVehicle);
		
		JButton btnSupplier = new JButton("Supplier");
		btnSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Supplier().setVisible(true);
				setVisible(false);
			}
		});
		btnSupplier.setToolTipText("Track");
		btnSupplier.setForeground(Color.WHITE);
		btnSupplier.setFont(new Font("Calibri", Font.BOLD, 15));
		btnSupplier.setBorder(null);
		btnSupplier.setBackground(Color.BLACK);
		btnSupplier.setBounds(425, 11, 126, 23);
		panel_2.add(btnSupplier);
		
		JButton btnCustomer = new JButton("Customer");
		btnCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Customer().setVisible(true);
				setVisible(false);
			}
		});
		btnCustomer.setToolTipText("Track");
		btnCustomer.setForeground(Color.WHITE);
		btnCustomer.setFont(new Font("Calibri", Font.BOLD, 15));
		btnCustomer.setBorder(null);
		btnCustomer.setBackground(Color.BLACK);
		btnCustomer.setBounds(561, 11, 138, 23);
		panel_2.add(btnCustomer);
		
		JButton btnShowRoom = new JButton("Show Room");
		btnShowRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Show_Room().setVisible(true);
				setVisible(false);
			}
		});
		btnShowRoom.setToolTipText("Track");
		btnShowRoom.setForeground(Color.WHITE);
		btnShowRoom.setFont(new Font("Calibri", Font.BOLD, 15));
		btnShowRoom.setBorder(null);
		btnShowRoom.setBackground(Color.BLACK);
		btnShowRoom.setBounds(709, 11, 132, 23);
		panel_2.add(btnShowRoom);
		
		JButton btnOrder = new JButton("Order");
		btnOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Order().setVisible(true);
				setVisible(false);
			}
		});
		btnOrder.setToolTipText("Track");
		btnOrder.setForeground(Color.WHITE);
		btnOrder.setFont(new Font("Calibri", Font.BOLD, 15));
		btnOrder.setBorder(null);
		btnOrder.setBackground(Color.BLACK);
		btnOrder.setBounds(851, 11, 132, 23);
		panel_2.add(btnOrder);
		
		JButton btnPayment = new JButton("Payment");
		btnPayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Payment().setVisible(true);
				setVisible(false);
			}
		});
		btnPayment.setToolTipText("Track");
		btnPayment.setForeground(Color.WHITE);
		btnPayment.setFont(new Font("Calibri", Font.BOLD, 15));
		btnPayment.setBorder(null);
		btnPayment.setBackground(Color.BLACK);
		btnPayment.setBounds(993, 11, 132, 23);
		panel_2.add(btnPayment);
		
		panel_3 = new JPanel();
		panel_3.setBounds(10, 104, 1240, 550);
		panel_3.setBackground(Color.GRAY);
		panel_3.setFont(new Font("Calibri", Font.BOLD, 18));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Vehicle ID");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(28, 29, 172, 31);
		panel_3.add(lblNewLabel);
		
		txtOrderId = new JTextField();
		txtOrderId.setBounds(210, 29, 186, 31);
		panel_3.add(txtOrderId);
		txtOrderId.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			searchRecord();
				
			}
		});
		txtOrderId.setColumns(10);
		
		JLabel lblVehicleId = new JLabel("Vehicle ID");
		lblVehicleId.setFont(new Font("Calibri", Font.BOLD, 25));
		lblVehicleId.setBounds(332, 153, 109, 31);
		panel_3.add(lblVehicleId);
		
		JLabel lblUpdateRecord = new JLabel("MANAGE RECORD");
		lblUpdateRecord.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUpdateRecord.setBounds(554, 106, 216, 31);
		panel_3.add(lblUpdateRecord);
		
		txtOrderUpdate = new JTextField();
		txtOrderUpdate.setColumns(10);
		txtOrderUpdate.setBounds(332, 195, 186, 31);
		panel_3.add(txtOrderUpdate);
		
		JLabel lblPackageName = new JLabel("Vehicle Type");
		lblPackageName.setFont(new Font("Calibri", Font.BOLD, 25));
		lblPackageName.setBounds(695, 153, 151, 31);
		panel_3.add(lblPackageName);
		
		txtVehicleType = new JTextField();
		txtVehicleType.setColumns(10);
		txtVehicleType.setBounds(695, 195, 186, 31);
		panel_3.add(txtVehicleType);
		
		JLabel lblLocation = new JLabel("VT_Model");
		lblLocation.setFont(new Font("Calibri", Font.BOLD, 25));
		lblLocation.setBounds(332, 267, 109, 31);
		panel_3.add(lblLocation);
		
		JLabel lblStatus = new JLabel("Engine Type");
		lblStatus.setFont(new Font("Calibri", Font.BOLD, 25));
		lblStatus.setBounds(698, 267, 127, 31);
		panel_3.add(lblStatus);
		
		txtVTModel = new JTextField();
		txtVTModel.setColumns(10);
		txtVTModel.setBounds(332, 321, 186, 31);
		panel_3.add(txtVTModel);
		
		txtEngineType = new JTextField();
		txtEngineType.setColumns(10);
		txtEngineType.setBounds(695, 321, 186, 31);
		panel_3.add(txtEngineType);
		
		txtEngineDisplacement = new JTextField();
		txtEngineDisplacement.setColumns(10);
		txtEngineDisplacement.setBounds(332, 424, 216, 31);
		panel_3.add(txtEngineDisplacement);
		
		JLabel lblUser = new JLabel("Engine Displacement");
		lblUser.setFont(new Font("Calibri", Font.BOLD, 25));
		lblUser.setBounds(332, 382, 230, 31);
		panel_3.add(lblUser);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addData();
				setToNull();
			}
		});
		btnAdd.setToolTipText("Delete");
		btnAdd.setFont(new Font("Calibri", Font.BOLD, 25));
		btnAdd.setBorder(null);
		btnAdd.setBackground(SystemColor.activeCaption);
		btnAdd.setBounds(189, 480, 202, 51);
		panel_3.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateRecord();
				setToNull();
			}
		});
		btnUpdate.setToolTipText("Delete");
		btnUpdate.setFont(new Font("Calibri", Font.BOLD, 25));
		btnUpdate.setBorder(null);
		btnUpdate.setBackground(SystemColor.activeCaption);
		btnUpdate.setBounds(450, 480, 202, 51);
		panel_3.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteRecord();
				setToNull();
			}
		});
		btnDelete.setToolTipText("Delete");
		btnDelete.setFont(new Font("Calibri", Font.BOLD, 25));
		btnDelete.setBorder(null);
		btnDelete.setBackground(SystemColor.activeCaption);
		btnDelete.setBounds(714, 480, 202, 51);
		panel_3.add(btnDelete);
		
		JLabel lblVehicleColor = new JLabel("Vehicle Color");
		lblVehicleColor.setFont(new Font("Calibri", Font.BOLD, 25));
		lblVehicleColor.setBounds(695, 382, 151, 31);
		panel_3.add(lblVehicleColor);
		
		textVehicleColor = new JTextField();
		textVehicleColor.setColumns(10);
		textVehicleColor.setBounds(695, 424, 186, 31);
		panel_3.add(textVehicleColor);
	}
}
